package com.busanit.spring.e_aop;

public interface Calculator {
    public long factorial(long num);
}
