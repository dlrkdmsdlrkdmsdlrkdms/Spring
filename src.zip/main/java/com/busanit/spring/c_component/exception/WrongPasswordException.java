package com.busanit.spring.c_component.exception;

public class WrongPasswordException extends RuntimeException {
}
