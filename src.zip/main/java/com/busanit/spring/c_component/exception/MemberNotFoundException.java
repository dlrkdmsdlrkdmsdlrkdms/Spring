package com.busanit.spring.c_component.exception;

public class MemberNotFoundException extends RuntimeException {
}
