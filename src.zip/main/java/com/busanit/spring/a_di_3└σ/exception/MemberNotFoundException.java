package com.busanit.spring.a_di_3장.exception;

public class MemberNotFoundException extends RuntimeException {
}
