package com.busanit.spring.f_db.exception;

public class WrongPasswordException extends RuntimeException {
}
