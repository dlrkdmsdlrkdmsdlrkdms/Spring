package com.busanit.spring.f_db.exception;

public class MemberNotFoundException extends RuntimeException {
}
