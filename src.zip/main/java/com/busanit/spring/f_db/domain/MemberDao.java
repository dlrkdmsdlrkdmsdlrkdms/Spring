package com.busanit.spring.f_db.domain;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

// 멤버 클래스의 데이터 접근 객체, 관심사 : 데이터 접근
public class MemberDao {

    private JdbcTemplate jdbcTemplate;
    // 생성하면서 dataSource 의존성 주입
    public MemberDao(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    // READ
    public Member selectByEmail(String email) {
        List<Member> resultList = jdbcTemplate.query(
                "SELECT * FROM MEMBER WHERE EMAIL = ?", new RowMapper<Member>() {
                    @Override
                    public Member mapRow(ResultSet rs, int rowNum) throws SQLException {
                        Member member = new Member(
                                rs.getString("EMAIL"),
                                rs.getString("PASSWORD"),
                                rs.getString("NAME"),
                                rs.getTimestamp("REGDATE").toLocalDateTime()
                        );
                        member.setId(rs.getLong("ID"));
                        return member;
                    }
                }, email);
        return resultList.isEmpty() ? null : resultList.get(0);
    }

    // CREATE
    public void insert(Member member) {

    }

    // UPDATE
    public void update(Member member) {

    }

    // READ ALL
    public Collection<Member> selectAll() {
        return null;
    }

}
