package com.busanit.spring.b_autowire.exception;

public class MemberNotFoundException extends RuntimeException {
}
