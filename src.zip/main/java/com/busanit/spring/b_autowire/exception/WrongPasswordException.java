package com.busanit.spring.b_autowire.exception;

public class WrongPasswordException extends RuntimeException {
}
